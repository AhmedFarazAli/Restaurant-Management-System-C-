import React from 'react';

const Footer = () => (
    <footer>
        <p className="copyright">©2018 BOOK IT GROUP, ALL RIGHTS RESERVED</p>
    </footer>
)

export default Footer;