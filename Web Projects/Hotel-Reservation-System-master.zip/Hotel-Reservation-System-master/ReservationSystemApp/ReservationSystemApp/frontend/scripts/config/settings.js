export const settings = {
    baseUrl: '/api',
    confirmationLimit: 30 * 60,
    defaultImageSize: {
        width: 20,
        height: 20
    },
    defaultTopHotelSize: 3
}