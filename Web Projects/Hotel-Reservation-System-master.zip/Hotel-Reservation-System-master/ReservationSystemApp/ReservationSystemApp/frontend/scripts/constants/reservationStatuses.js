export const statuses = {
    PENDING: 1,
    CONFIRMED: 2,
    PAID: 3,
    CANCELLED: 4
}