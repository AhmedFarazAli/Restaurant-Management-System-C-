﻿namespace Services.Models
{
    public class ImageModel
    {
        public int ImageId { get; set; }

        public ImageModel(int imageId)
        {
            ImageId = imageId;
        }
    }
}
