﻿namespace Services.Models.RequestModels
{
    public class PageRequestModel
    {
        public int Page { get; set; }
        public int? PageSize { get; set; }
    }
}
