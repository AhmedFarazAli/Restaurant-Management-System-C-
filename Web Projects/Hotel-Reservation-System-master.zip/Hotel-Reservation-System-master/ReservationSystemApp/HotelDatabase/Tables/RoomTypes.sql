﻿CREATE TABLE [dbo].[RoomTypes]
(
	RoomTypeId INT NOT NULL PRIMARY KEY,
	RoomType nvarchar(20)
)
