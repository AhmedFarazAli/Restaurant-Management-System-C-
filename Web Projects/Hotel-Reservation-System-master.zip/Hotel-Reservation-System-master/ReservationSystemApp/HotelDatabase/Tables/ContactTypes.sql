﻿CREATE TABLE [dbo].[ContactTypes]
(
	ContactTypeId INT NOT NULL PRIMARY KEY,
	ContactType nvarchar(20) NOT NULL
)
