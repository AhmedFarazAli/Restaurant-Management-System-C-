﻿CREATE TABLE [dbo].[Services]
(
	[ServiceId] INT NOT NULL IDENTITY PRIMARY KEY,
	[Name] nvarchar(MAX) null
)
