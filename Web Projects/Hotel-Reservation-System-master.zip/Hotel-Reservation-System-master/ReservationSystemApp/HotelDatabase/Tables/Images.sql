﻿CREATE TABLE [dbo].[Images]
(
	[ImageId] INT NOT NULL IDENTITY PRIMARY KEY,
	FileName nvarchar(MAX) NOT NULL
)
