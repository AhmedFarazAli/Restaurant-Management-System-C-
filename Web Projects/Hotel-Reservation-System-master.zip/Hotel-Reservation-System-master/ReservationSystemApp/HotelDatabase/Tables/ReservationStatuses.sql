﻿CREATE TABLE [dbo].[ReservationStatuses]
(
	StatusId INT NOT NULL PRIMARY KEY,
	Status nvarchar(20) NOT NULL
)
