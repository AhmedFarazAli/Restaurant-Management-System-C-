﻿namespace DataLayer.Entities
{
    public enum ReservationStatusEnum
    {   
        None,
        Pending,
        Confirmed,
        Paid,
        Cancelled    
    }
}
