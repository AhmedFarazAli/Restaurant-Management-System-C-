﻿namespace DataLayer.Entities
{
    public enum RoomTypeEnum
    {
        Single,
        Double,
        Triple,
        Quad,
        Queen,
        King,
        Twin,
        Suite,
        Apartment,
        PresidentSuite,
        ConnectingRooms
    }
}
