﻿namespace DataLayer.Entities
{
    public enum ContactType
    {
        Email,
        Phone,
        Viber, 
        Skype,
        WhatsApp,
        Telegram,
        Facebook,
        Instagram,
        Twitter,
        LinkedIn,
        Snapchat,
        VK
    }
}
